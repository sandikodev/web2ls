<html>
    <title>Calendar</title>
<link rel="icon" type="image/x-icon" href="https://cdn.sgb.or.id/sgb_img/favicon.ico"/>
<head>   
<link href="calendar.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php
include 'calendar.php';
 
$calendar = new Calendar();
 
echo $calendar->show();
?>
</body>
</html>       