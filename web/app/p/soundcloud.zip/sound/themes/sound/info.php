<?php
// Theme Name
$name = 'Sound';

// Theme Author
$author = 'phpSound';

// Theme URL
$url = 'http://phpsound.com';

// Theme Version
$version = '2.0.1';
?>