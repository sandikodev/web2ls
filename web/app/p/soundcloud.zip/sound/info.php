<?php
// Software Name
$name = 'phpSound';

// Software Author
$author = 'phpSound';

// Software URL
$url = 'http://phpsound.com';

// Software Version
$version = '4.2.0';
?>